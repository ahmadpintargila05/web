-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2023 at 02:34 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `printer`
--

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `foto` text NOT NULL,
  `harga` int(100) NOT NULL,
  `stok` int(50) NOT NULL,
  `deskripsi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `foto`, `harga`, `stok`, `deskripsi`) VALUES
(8, 'Laptop 1', 'laptoopp.jpg', 15000000, 40, 'Diskon 30%'),
(9, 'Laptop 2', 'laptoop.jpg', 6500000, 50, 'Diskon 10%'),
(10, 'Laptop 3', 'laptop3.jpg', 10000000, 20, 'Diskon 40%'),
(11, 'Laptop 4', 'laptop4.jpg', 7000000, 99, 'Diskon 10%'),
(12, 'Laptop 5', 'laptop5.jpg', 8500000, 89, 'Diskon 30%'),
(17, 'Laptop 6', 'laptop6.jpg', 25000000, 30, 'Diskon 5%');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tanggal_transaksi` date NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `nomor_whatsapp` int(22) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga` int(22) NOT NULL,
  `subtotal` int(22) NOT NULL,
  `foto` text NOT NULL,
  `status` enum('proses','terverifikasi','ditolak') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tanggal_transaksi`, `nama_lengkap`, `alamat`, `nomor_whatsapp`, `nama_produk`, `harga`, `subtotal`, `foto`, `status`) VALUES
(7, '0000-00-00', 'test', 'test', 0, 'Printer1', 100000, 1, 'printer1.png', 'terverifikasi'),
(8, '0000-00-00', 'test', 'test', 0, 'Printer4', 100000, 1, 'printer4.jpg', 'ditolak'),
(9, '0000-00-00', 'test', 'test', 0, 'Printer2', 120000, 1, 'printer2.jpg', 'terverifikasi'),
(10, '0000-00-00', 'test', 'test', 0, 'Printer1', 100000, 400000, 'printer1.png', 'proses'),
(11, '0000-00-00', 'test', 'test', 0, 'Printer1', 100000, 400000, 'printer1.png', 'proses'),
(12, '0000-00-00', 'test', 'test', 0, 'Printer1', 100000, 400000, 'printer1.png', 'proses'),
(13, '0000-00-00', 'PP', 'Jl Mardani', 0, 'Printer2', 60000, 200000, 'printer1.png', 'proses'),
(14, '0000-00-00', 'PP', 'Jl Mardani', 0, 'Printer2', 60000, 300000, 'printer2.jpg', 'ditolak'),
(15, '2023-03-31', 'PP', 'testi', 0, 'Printer9', 100000, 100000, 'printer9.png', 'terverifikasi'),
(16, '2023-03-31', 'PP', 'qibar', 0, 'Printer4', 100000, 100000, 'printer9.png', 'ditolak'),
(17, '2023-03-31', 'PP', 'qibar', 0, 'Printer4', 100000, 100000, 'printer4.jpg', 'ditolak'),
(18, '2023-04-06', '', '', 0, 'Laptop 6', 0, 75000000, 'laptop6.jpg', 'ditolak'),
(19, '2023-04-06', '', 'jakbar', 0, 'Laptop 5', 0, 7000000, 'laptop4.jpg', 'terverifikasi'),
(20, '2023-04-06', '', 'jakbar', 0, 'Laptop 5', 0, 8500000, 'laptop5.jpg', 'terverifikasi'),
(21, '2023-04-06', 'JENO', 'koriyah', 0, 'Laptop 6', 0, 125000000, 'laptop6.jpg', 'terverifikasi'),
(22, '2023-04-09', 'JENO', 'dimana aja lah', 0, 'Laptop 6', 0, 125000000, 'laptop6.jpg', 'terverifikasi'),
(23, '2023-04-09', 'JENO', 'kunir', 0, 'Laptop 2', 0, 30000000, 'laptoopp.jpg', 'terverifikasi'),
(24, '2023-04-09', 'JENO', 'kunir', 0, 'Laptop 2', 0, 19500000, 'laptoop.jpg', 'ditolak');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `foto` text DEFAULT NULL,
  `roles` enum('Admin','Customer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_lengkap`, `username`, `password`, `foto`, `roles`) VALUES
(1, 'Aliya Najma', 'aliya', '123', 'aliya.JPG', 'Admin'),
(14, 'JENO', 'leejeno', '12345', '6d63d3c8-7b36-4418-a0f2-17b183573e62.jfif', 'Customer'),
(18, 'JAEHYUN', 'jaehyunggtg', '1234', '6f8334fb-a9fb-4bd9-8263-7b62e1e41623.jfif', 'Customer'),
(19, 'CHANYEOL PARK', 'bangcy', '123', 'bang cy.jpg', 'Customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
