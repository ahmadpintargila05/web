<nav class="navbar navbar-expand-lg bg-white">
  <div class="container-fluid">
    <a class="navbar-brand" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></a>
  </div>
</nav>